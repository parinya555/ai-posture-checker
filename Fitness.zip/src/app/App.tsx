export default function App() {
  return (
    <div className="size-full flex items-center justify-center bg-neutral-100">
      <div
        className="shadow-2xl overflow-hidden flex flex-col"
        style={{ width: '393px', height: '852px', backgroundColor: '#0F0F0F' }}
      >
        {/* Status Bar */}
        <div className="text-white px-6 py-3 flex items-center justify-between text-xs">
          <span>9:41</span>
          <div className="flex items-center gap-1">
            <div className="w-4 h-3 border border-white rounded-sm relative">
              <div className="absolute inset-0.5 bg-white rounded-sm"></div>
            </div>
          </div>
        </div>

        {/* Content Area */}
        <div className="flex-1 px-6 py-8">
          <p className="leading-relaxed" style={{ fontFamily: 'Poppins, sans-serif', fontSize: '32px', fontWeight: 'bold', color: 'white' }}>
            Poogun
          </p>
          <div className="flex gap-4">
            <div
              className="flex flex-col items-center justify-center"
              style={{ width: '160px', height: '110px', borderRadius: '20px', backgroundColor: '#1E1E1E' }}
            >
              <p className="text-white" style={{ fontFamily: 'Poppins, sans-serif' }}>Calories</p>
              <p style={{ fontFamily: 'Poppins, sans-serif', color: '#39FF14' }}>560 kcal</p>
            </div>
            <div
              className="flex flex-col items-center justify-center"
              style={{ width: '160px', height: '110px', borderRadius: '20px', backgroundColor: '#1E1E1E' }}
            >
              <p className="text-white" style={{ fontFamily: 'Poppins, sans-serif' }}>Full Body Workout</p>
              <p style={{ fontFamily: 'Poppins, sans-serif', color: '#A0A0A0' }}>45 Minutes • Beginner</p>
            </div>
          </div>
          <div className="flex gap-4 mt-4">
            <div
              className="flex flex-col items-center justify-center"
              style={{ width: '160px', height: '110px', borderRadius: '20px', backgroundColor: '#1E1E1E' }}
            >
              <p className="text-white" style={{ fontFamily: 'Poppins, sans-serif' }}>ABS Challenge</p>
              <p style={{ fontFamily: 'Poppins, sans-serif', color: '#A0A0A0' }}>20 Minutes • Intermediate</p>
            </div>
          </div>
          <div
            className="flex items-center justify-center"
            style={{ width: '350px', height: '60px', borderRadius: '20px', backgroundColor: '#39FF14' }}
          >
            <p style={{ fontFamily: 'Poppins, sans-serif', fontWeight: 'bold', color: 'black' }}>Start Workout</p>
          </div>
        </div>
      </div>
    </div>
  );
}