
  # Fitness

  This is a code bundle for Fitness. The original project is available at https://www.figma.com/design/RhdChhUnCrVKycPNt1B8Op/Fitness.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  